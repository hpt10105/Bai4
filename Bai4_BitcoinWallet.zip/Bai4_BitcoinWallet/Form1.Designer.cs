﻿
namespace Bai4_BitcoinWallet
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.btnDerive = new System.Windows.Forms.Button();
            this.btnDownload = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();

            this.lblPrivateKey = new System.Windows.Forms.Label();
            this.lblWif = new System.Windows.Forms.Label();
            this.lblPublicKey = new System.Windows.Forms.Label();
            this.lblLegacy = new System.Windows.Forms.Label();
            this.lblNested = new System.Windows.Forms.Label();
            this.lblSegwit = new System.Windows.Forms.Label();

            this.txtPrivateKey = new System.Windows.Forms.TextBox();
            this.txtWif = new System.Windows.Forms.TextBox();
            this.txtPublicKey = new System.Windows.Forms.TextBox();
            this.txtLegacy = new System.Windows.Forms.TextBox();
            this.txtNested = new System.Windows.Forms.TextBox();
            this.txtSegwit = new System.Windows.Forms.TextBox();

            this.SuspendLayout();

            // Form
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(850, 590);
            this.Name = "Form1";
            this.Text = "Bitcoin Wallet Generator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;

            // Title
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font(
                "Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(190, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(450, 41);
            this.lblTitle.Text = "BITCOIN WALLET GENERATOR";
            this.lblTitle.Click += new System.EventHandler(this.lblTitle_Click);

            // Generate Wallet button
            this.btnGenerate.Location = new System.Drawing.Point(35, 95);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(220, 45);
            this.btnGenerate.TabIndex = 0;
            this.btnGenerate.Text = "Generate Wallet";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);

            // Derive button
            this.btnDerive.Location = new System.Drawing.Point(35, 160);
            this.btnDerive.Name = "btnDerive";
            this.btnDerive.Size = new System.Drawing.Size(220, 45);
            this.btnDerive.TabIndex = 1;
            this.btnDerive.Text = "Derive Public / Address";
            this.btnDerive.UseVisualStyleBackColor = true;
            this.btnDerive.Click += new System.EventHandler(this.btnDerive_Click);

            // Download button
            this.btnDownload.Location = new System.Drawing.Point(35, 225);
            this.btnDownload.Name = "btnDownload";
            this.btnDownload.Size = new System.Drawing.Size(220, 45);
            this.btnDownload.TabIndex = 2;
            this.btnDownload.Text = "Download JSON";
            this.btnDownload.UseVisualStyleBackColor = true;
            this.btnDownload.Click += new System.EventHandler(this.btnDownload_Click);

            // Clear button
            this.btnClear.Location = new System.Drawing.Point(35, 290);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(220, 45);
            this.btnClear.TabIndex = 3;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);

            // Label: Private Key
            this.lblPrivateKey.AutoSize = true;
            this.lblPrivateKey.Location = new System.Drawing.Point(300, 80);
            this.lblPrivateKey.Name = "lblPrivateKey";
            this.lblPrivateKey.Size = new System.Drawing.Size(76, 16);
            this.lblPrivateKey.Text = "Private Key";

            // TextBox: Private Key
            this.txtPrivateKey.Location = new System.Drawing.Point(300, 103);
            this.txtPrivateKey.Name = "txtPrivateKey";
            this.txtPrivateKey.Size = new System.Drawing.Size(510, 23);
            this.txtPrivateKey.ReadOnly = true;
            this.txtPrivateKey.TabIndex = 4;

            // Label: Private Key WIF
            this.lblWif.AutoSize = true;
            this.lblWif.Location = new System.Drawing.Point(300, 145);
            this.lblWif.Name = "lblWif";
            this.lblWif.Size = new System.Drawing.Size(91, 16);
            this.lblWif.Text = "Private Key WIF";

            // TextBox: WIF
            this.txtWif.Location = new System.Drawing.Point(300, 168);
            this.txtWif.Name = "txtWif";
            this.txtWif.Size = new System.Drawing.Size(510, 23);
            this.txtWif.ReadOnly = true;
            this.txtWif.TabIndex = 5;

            // Label: Public Key
            this.lblPublicKey.AutoSize = true;
            this.lblPublicKey.Location = new System.Drawing.Point(300, 210);
            this.lblPublicKey.Name = "lblPublicKey";
            this.lblPublicKey.Size = new System.Drawing.Size(72, 16);
            this.lblPublicKey.Text = "Public Key";

            // TextBox: Public Key
            this.txtPublicKey.Location = new System.Drawing.Point(300, 233);
            this.txtPublicKey.Name = "txtPublicKey";
            this.txtPublicKey.Size = new System.Drawing.Size(510, 23);
            this.txtPublicKey.ReadOnly = true;
            this.txtPublicKey.TabIndex = 6;

            // Label: Legacy Address
            this.lblLegacy.AutoSize = true;
            this.lblLegacy.Location = new System.Drawing.Point(300, 275);
            this.lblLegacy.Name = "lblLegacy";
            this.lblLegacy.Size = new System.Drawing.Size(100, 16);
            this.lblLegacy.Text = "Legacy Address";

            // TextBox: Legacy Address
            this.txtLegacy.Location = new System.Drawing.Point(300, 298);
            this.txtLegacy.Name = "txtLegacy";
            this.txtLegacy.Size = new System.Drawing.Size(510, 23);
            this.txtLegacy.ReadOnly = true;
            this.txtLegacy.TabIndex = 7;

            // Label: Nested SegWit Address
            this.lblNested.AutoSize = true;
            this.lblNested.Location = new System.Drawing.Point(300, 340);
            this.lblNested.Name = "lblNested";
            this.lblNested.Size = new System.Drawing.Size(130, 16);
            this.lblNested.Text = "Nested SegWit Address";

            // TextBox: Nested SegWit Address
            this.txtNested.Location = new System.Drawing.Point(300, 363);
            this.txtNested.Name = "txtNested";
            this.txtNested.Size = new System.Drawing.Size(510, 23);
            this.txtNested.ReadOnly = true;
            this.txtNested.TabIndex = 8;

            // Label: Native SegWit Address
            this.lblSegwit.AutoSize = true;
            this.lblSegwit.Location = new System.Drawing.Point(300, 405);
            this.lblSegwit.Name = "lblSegwit";
            this.lblSegwit.Size = new System.Drawing.Size(135, 16);
            this.lblSegwit.Text = "Native SegWit Address";
            this.lblSegwit.Click += new System.EventHandler(this.lblSegwit_Click);

            // TextBox: Native SegWit Address
            this.txtSegwit.Location = new System.Drawing.Point(300, 428);
            this.txtSegwit.Name = "txtSegwit";
            this.txtSegwit.Size = new System.Drawing.Size(510, 23);
            this.txtSegwit.ReadOnly = true;
            this.txtSegwit.TabIndex = 9;

            // Add controls to Form
            this.Controls.Add(this.lblTitle);

            this.Controls.Add(this.btnGenerate);
            this.Controls.Add(this.btnDerive);
            this.Controls.Add(this.btnDownload);
            this.Controls.Add(this.btnClear);

            this.Controls.Add(this.lblPrivateKey);
            this.Controls.Add(this.txtPrivateKey);

            this.Controls.Add(this.lblWif);
            this.Controls.Add(this.txtWif);

            this.Controls.Add(this.lblPublicKey);
            this.Controls.Add(this.txtPublicKey);

            this.Controls.Add(this.lblLegacy);
            this.Controls.Add(this.txtLegacy);

            this.Controls.Add(this.lblNested);
            this.Controls.Add(this.txtNested);

            this.Controls.Add(this.lblSegwit);
            this.Controls.Add(this.txtSegwit);

            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.Button btnDerive;
        private System.Windows.Forms.Button btnDownload;
        private System.Windows.Forms.Button btnClear;

        private System.Windows.Forms.Label lblPrivateKey;
        private System.Windows.Forms.Label lblWif;
        private System.Windows.Forms.Label lblPublicKey;
        private System.Windows.Forms.Label lblLegacy;
        private System.Windows.Forms.Label lblNested;
        private System.Windows.Forms.Label lblSegwit;

        private System.Windows.Forms.TextBox txtPrivateKey;
        private System.Windows.Forms.TextBox txtWif;
        private System.Windows.Forms.TextBox txtPublicKey;
        private System.Windows.Forms.TextBox txtLegacy;
        private System.Windows.Forms.TextBox txtNested;
        private System.Windows.Forms.TextBox txtSegwit;
    }
}
