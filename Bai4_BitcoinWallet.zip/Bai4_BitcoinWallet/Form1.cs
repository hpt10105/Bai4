
using System;
using System.IO;
using System.Windows.Forms;
using NBitcoin;
using Newtonsoft.Json;

namespace Bai4_BitcoinWallet
{
    public partial class Form1 : Form
    {
        private Key privateKey;
        private PubKey publicKey;
        private string privateWif = "";

        public Form1()
        {
            InitializeComponent();
        }

        // NUT GENERATE WALLET
        private void btnGenerate_Click(object sender, EventArgs e)
        {
            try
            {
                privateKey = new Key();
                publicKey = null;

                privateWif = privateKey
                    .GetWif(Network.Main).ToString();

                txtPrivateKey.Text = privateKey.ToHex();
                txtWif.Text = privateWif;

                txtPublicKey.Clear();
                txtLegacy.Clear();
                txtNested.Clear();
                txtSegwit.Clear();

                MessageBox.Show("Tao Private Key thanh cong!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Loi: " + ex.Message);
            }
        }

        // NUT DERIVE PUBLIC / ADDRESS
        private void btnDerive_Click(object sender, EventArgs e)
        {
            if (privateKey == null)
            {
                MessageBox.Show("Hay nhan Generate Wallet truoc!");
                return;
            }

            try
            {
                publicKey = privateKey.PubKey;

                txtPublicKey.Text = publicKey.ToHex();

                txtLegacy.Text = publicKey.GetAddress(
                    ScriptPubKeyType.Legacy,
                    Network.Main).ToString();

                txtNested.Text = publicKey.GetAddress(
                    ScriptPubKeyType.SegwitP2SH,
                    Network.Main).ToString();

                txtSegwit.Text = publicKey.GetAddress(
                    ScriptPubKeyType.Segwit,
                    Network.Main).ToString();

                MessageBox.Show("Tao dia chi Bitcoin thanh cong!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Loi: " + ex.Message);
            }
        }

        // NUT CLEAR
        private void btnClear_Click(object sender, EventArgs e)
        {
            privateKey = null;
            publicKey = null;
            privateWif = "";

            txtPrivateKey.Clear();
            txtWif.Clear();
            txtPublicKey.Clear();
            txtLegacy.Clear();
            txtNested.Clear();
            txtSegwit.Clear();
        }

        // NUT DOWNLOAD JSON
        private void btnDownload_Click(object sender, EventArgs e)
        {
            if (privateKey == null || publicKey == null)
            {
                MessageBox.Show(
                    "Hay tao vi va dia chi truoc!");
                return;
            }

            var wallet = new
            {
                PrivateKey = privateKey.ToHex(),
                PrivateKeyWIF = privateWif,
                PublicKey = publicKey.ToHex(),
                LegacyAddress = txtLegacy.Text,
                NestedSegWitAddress = txtNested.Text,
                NativeSegWitAddress = txtSegwit.Text
            };

            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Filter = "JSON files (*.json)|*.json";
                dialog.FileName = "bitcoin_wallet.json";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    string json = JsonConvert.SerializeObject(
                        wallet, Formatting.Indented);

                    File.WriteAllText(dialog.FileName, json);

                    MessageBox.Show("Da luu file JSON thanh cong!");
                }
            }
        }

        private void lblSegwit_Click(object sender, EventArgs e)
        {
            // Su kien Label, khong can xu ly
        }

        private void txtPrivateKey_TextChanged(object sender, EventArgs e)
        {
            // Su kien TextBox, khong can xu ly
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {
            // Su kien Label, khong can xu ly
        }
    }
}
